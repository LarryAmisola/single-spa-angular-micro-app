// Anything exported from this file is importable by other in-browser modules.
export function publicApiFunction() {}

import { BehaviorSubject } from "rxjs";

  export const BaseService = Object.freeze({
    list$: new BehaviorSubject<string[]>([]),
    post: [] =[],

    addTodo(last_name: string, first_name: string, email: string, mobile: string): void {
      const post = {last_name: last_name, first_name: first_name, email: email, mobile: mobile};
      this.list$.next([...this.list$.getValue(), post]);
    },
  });
