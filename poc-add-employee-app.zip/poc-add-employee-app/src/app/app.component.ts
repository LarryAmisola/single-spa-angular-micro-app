import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgForm } from "@angular/forms";
import { BaseService } from '@poc/utility';

import { Subscription, Subject } from 'rxjs';

export interface Todos {
  title: string;
}

@Component({
  selector: 'poc-add-employee-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  
  todo: [] = [];
  Subject= new Subject<Todos[]>();

  constructor() {}

  ngOnInit():void {
  }

  // addTodo(): void {
  //   console.log('ADD TODO =', this.todo);
  //   if (!this.todo) {
  //     return;
  //   }
    
  //   BaseService.addTodo(this.todo);
  //   BaseService.ArrayList$.push(this.todo);
  //   this.todo = '';
  // }
  onSaveEmployee(form: NgForm) {
    if (form.invalid) {
      return;
    }
    console.log(form.value.last_name, form.value.first_name, form.value.email, form.value.mobile);
    BaseService.addTodo(form.value.last_name, form.value.first_name, form.value.email, form.value.mobile);
    
    form.resetForm();
  }



  ngOnDestroy():void {
    // BaseService.list$.next([this.todo]);
  }
}
