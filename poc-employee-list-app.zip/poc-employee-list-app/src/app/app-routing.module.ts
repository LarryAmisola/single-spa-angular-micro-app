import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';

import { EmptyRouteComponent } from './empty-route/empty-route.component';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';

const routes: Routes = [
  // { 
  //   path: '',
  //   redirectTo: '/employeelist',
  //   pathMatch: 'full'
  // },
  {
    path: '**', 
    component: EmptyRouteComponent
  },
  // {
  //   path: 'employeelist', 
  //   component: EmployeeListComponent
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
})
export class AppRoutingModule { }
