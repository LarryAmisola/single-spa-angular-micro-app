import { Component, OnInit, OnDestroy, NgZone } from '@angular/core';
import { Subscription } from "rxjs";

import { BaseService } from '@poc/utility';

export interface Todos {
  first_name: string;
  last_name: string;
  email: string;
  mobile: string;
}

@Component({
  selector: 'poc-employee-list-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {

  todos: Todos[] = [];
  private postSubscription: Subscription;

  constructor(private zone:NgZone) {
    this.postSubscription = BaseService.list$
      .subscribe((list: Todos[]) => {
        this.zone.run(() => { 
          this.todos = list;
          console.log('TODOS LIST =', this.todos);
        });
      });
  }

  ngOnInit():void {
  }

  observeTodos(): void {
    
  }

  ngOnDestroy():void {
    this.postSubscription.unsubscribe();
  }
}
