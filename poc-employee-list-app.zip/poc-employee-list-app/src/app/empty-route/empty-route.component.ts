import { Component } from '@angular/core';

@Component({
  selector: 'poc-employee-list-empty-route',
  template: '',
})
export class EmptyRouteComponent {}
